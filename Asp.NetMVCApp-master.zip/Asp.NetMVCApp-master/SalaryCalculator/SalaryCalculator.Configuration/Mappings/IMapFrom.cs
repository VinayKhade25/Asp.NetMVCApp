﻿namespace SalaryCalculator.Configuration.Mappings
{
    public interface IMapFrom<T>
    {
    }
}