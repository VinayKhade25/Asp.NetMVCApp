﻿namespace SalaryCalculator.Configuration.Mappings
{
    public interface IMapTo<T>
    {
    }
}