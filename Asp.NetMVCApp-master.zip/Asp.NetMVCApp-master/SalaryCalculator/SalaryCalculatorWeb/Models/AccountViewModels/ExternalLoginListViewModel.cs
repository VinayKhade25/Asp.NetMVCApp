﻿namespace SalaryCalculatorWeb.Models.AccountViewModels
{
    public class ExternalLoginListViewModel
    {
        public string ReturnUrl { get; set; }
    }
}