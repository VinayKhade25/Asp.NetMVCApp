﻿using SalaryCalculator.Data.Models;

namespace SalaryCalculator.Tests.Mocks
{
   public class FakeRemunerationBill : RemunerationBill
    {
        public FakeRemunerationBill()
            : base()
        {
                
        }
    }
}
