﻿using SalaryCalculator.Utilities.Calculations;

namespace SalaryCalculator.Tests.Mocks
{
    public class FakePayroll : Payroll
    {
        public FakePayroll()
            : base()
        {
                
        }
    }
}
