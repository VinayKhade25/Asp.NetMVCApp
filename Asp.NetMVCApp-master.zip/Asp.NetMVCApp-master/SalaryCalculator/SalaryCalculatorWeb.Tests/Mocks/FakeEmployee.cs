﻿using SalaryCalculator.Data.Models;

namespace SalaryCalculator.Tests.Mocks
{
    public class FakeEmployee : Employee
    {
        public FakeEmployee() 
            : base()
        {

        }
    }
}
