﻿using SalaryCalculator.Data.Models;

namespace SalaryCalculator.Tests.Mocks
{
   public class FakeSelfEmployment : SelfEmployment
    {
        public FakeSelfEmployment()
            : base()
        {

        }
    }
}
