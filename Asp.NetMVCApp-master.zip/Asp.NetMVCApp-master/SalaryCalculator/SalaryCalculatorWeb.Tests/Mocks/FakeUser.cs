﻿using SalaryCalculator.Data.Models;

namespace SalaryCalculator.Tests.Mocks
{
    public class FakeUser : User
    {
        public FakeUser() 
            : base()
        {

        }
    }
}
